package com.demo.personalfinancetracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PersonalfinancetrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
